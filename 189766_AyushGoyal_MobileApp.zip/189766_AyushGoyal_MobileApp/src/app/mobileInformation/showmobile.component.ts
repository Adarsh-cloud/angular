import { Component, OnInit } from '@angular/core';
import { MobileService } from '../services/mobile.service';
import { Mobile } from '../models/mobile.model';

@Component({
  selector: 'app-showmobile',
  templateUrl: './showmobile.component.html',
  styleUrls: ['./showmobile.component.css']
})
export class ShowMobileComponent implements OnInit {

  mobiles:Mobile[]=[];

  constructor(private mobileSer: MobileService) { }

  ngOnInit() {
    this.mobiles = this.mobileSer.getMobileData();
  }



  deleteMob(index:number)
  {
    this.mobiles.splice(index,1);
  }

}
