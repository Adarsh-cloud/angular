import { Injectable } from "@angular/core";
import { Mobile } from "../models/mobile.model";

@Injectable()
export class MobileService
{
    mobile:Mobile[]=[
        {
            mobileID:1001,
            mobileName:"iphone Xs max",
            mobilePrice:85000,
            mobileBrand:"Apple"
        },
       
    ]

    getMobileData()
    {
        return this.mobile;
    }

    addMob(mob:Mobile){
        this.mobile.push(mob);
        console.log("added");
    }
}