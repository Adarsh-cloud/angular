import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'typeScript';
  Employees:any;
  Employee: any[] =
    [
      { empId: 1001, empName: "Rahul", empSal: 9000, empDep: "Java" },
      { empId: 1002, empName: "Sachin", empSal: 19000, empDep: "OraApps" },
      { empId: 1003, empName: "Vikash", empSal: 29000, empDep: "BI" },
    ];

  updateEmpId: string;
  updateEmpName: string;
  updateEmpSal: string;
  updateEmpDep: string;

  constructor() { }
  addEmployee(id, name, sal, dept) {
    console.log({ id, name, sal, dept })
    this.Employee.push({ empId: id, empName: name, empSal: sal, empDep: dept })
  }
  deleteEmployee(value: any) {
    console.log(value);
    this.Employee = this.Employee.filter((emp) => emp.empId != value)

  }
  findElement(value) {
    //confirm("You want to Update");
    console.log(value);
    let emp = this.Employee.find((emp) => emp.empId == value);
    this.updateEmpId = emp.empId;
    this.updateEmpName = emp.empName;
    this.updateEmpSal = emp.empSal;
    this.updateEmpDep = emp.empDep;
  }

  updateEmployee() {
    let i = this.Employee.findIndex((emp) => emp.empId == this.updateEmpId);
    this.Employee[i] = { empId: this.updateEmpId, empName: this.updateEmpName, empSal: this.updateEmpSal, empDep: this.updateEmpDep }
  }
  
  searchEmployee(value){
    console.log(value);
    this.Employees=this.Employee.find(emp=>emp.empId == value);
   
  }
}
