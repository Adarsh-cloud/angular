import { Component, OnInit } from '@angular/core';
//import {FormGroup, FormControl, Validators} from '@angular/forms';
import {FormGroup, Validators,FormBuilder} from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
  
})
export class AppComponent implements OnInit{
//   title = 'firstApp';
//   name:string="Tom";
// process(){
//   alert("Welcome");
// }
// processData(event)
// {
//   this.name=event.target.value;
// }
// day:number=1;
// content:string="Hello world";
// processForm(value:any){
//   console.log(value);
// }

//Reactive Forms
// userForm:FormGroup=new FormGroup({
//   name:new FormControl(null,[Validators.required,Validators.minLength(4),Validators.maxLength(10)]),
//   email:new FormControl(),
//   address:new FormGroup({
//     street:new FormControl(),
//     city:new FormControl(),
//     pincode:new FormControl(null,Validators.pattern("[1-9][0-9]{5}"))
//   })
// });
userForm:FormGroup;
constructor(private formBuilder:FormBuilder)
{}
ngOnInit(){
  this.userForm=this.formBuilder.group({
    name:[null,[Validators.required,Validators.minLength(4),Validators.maxLength(10)]],
    email:[],
    address:this.formBuilder.group({
      street:[],
      city:[],
      pincode:[null,Validators.pattern("[1-9][0-9]{5}")]
    })
  })
}
process()
{
  console.log(this.userForm.value);
}
}