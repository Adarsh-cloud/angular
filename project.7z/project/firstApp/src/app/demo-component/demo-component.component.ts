import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo-component',
  /*templateUrl: './demo-component.component.html',
  styleUrls: ['./demo-component.component.css']*/
  template:`<h1> Hello World</h1>`
})
export class DemoComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
