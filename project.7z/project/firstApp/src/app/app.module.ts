import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DemoComponentComponent } from './demo-component/demo-component.component';
import { CustomerComponent } from './customer.component';
import { EmployeeListComponent } from './employee/employee-list.component';
import { EmpComponent } from './emp/emp.component';
import { EmployeeCountComponent } from './employee/employee-count.component';
import { ColorDirectiveDirective } from './color-directive.directive';
import { ChangeCaseDirective } from './change-case.directive';
import { DemoDirective } from './demo.directive';
import { EmployeeTitlePipe } from './employee/employee-title.pipe';
import { EmployeeFilterPipe } from './employee/employee-filter.pipe';
import { EmployeeService } from './employee/employee.service';
import {ReactiveFormsModule} from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    DemoComponentComponent,
    CustomerComponent,
    EmployeeListComponent,
    EmpComponent,
    EmployeeCountComponent,
    ColorDirectiveDirective,
    ChangeCaseDirective,
    DemoDirective,
    EmployeeTitlePipe,
    EmployeeFilterPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
