export interface IEmployee {
    code:String;
    name:string;
    gender:string;
    annualSalary:number;
    dateOfBirth:string;
}