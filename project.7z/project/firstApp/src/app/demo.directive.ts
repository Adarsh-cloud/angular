import { Directive, ElementRef, Renderer, HostListener, HostBinding } from '@angular/core';

@Directive({
  selector: '[appDemo]'
})
export class DemoDirective {

  @HostBinding('style.border')
  border:string;
  @HostListener('click')
  onClick()
  {
    this.renderer.setElementStyle(this.el.nativeElement,'color','green');
    this.border='5px solid red';
  }
  constructor(private el:ElementRef,private renderer:Renderer) { }

}
