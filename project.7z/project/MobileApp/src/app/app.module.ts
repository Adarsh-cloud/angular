﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import {FormsModule,ReactiveFormsModule} 
from '@angular/forms';
import {Routes, RouterModule} from '@angular/router';
import { ShowMobileComponent } from './mobileInformation/showmobile.component'
import { MobileService } from './services/mobile.service';;
import { AddMobileComponent } from './mobileInformation/add-mobile.component'
const appRoutes:Routes=
[
    {path:"",redirectTo:"/show",pathMatch:"full"},
    {path:"show",component:ShowMobileComponent},
    {path:"add",component:AddMobileComponent},
    
]
@NgModule({
    imports: [BrowserModule,
         FormsModule ,ReactiveFormsModule,
          RouterModule.forRoot(appRoutes) ],
    declarations: [
        AppComponent, ShowMobileComponent, AddMobileComponent],
    providers: [MobileService ],
    bootstrap: [AppComponent]
})

export class AppModule { }