export class Mobile
{   
    mobileID:number;
    mobileName:string;
    mobilePrice:number;
    mobileBrand:string;
}