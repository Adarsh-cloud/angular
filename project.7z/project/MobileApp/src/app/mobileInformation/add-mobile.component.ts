import { Component, OnInit } from '@angular/core';
import { MobileService } from '../services/mobile.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Mobile } from '../models/mobile.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-mobile',
  templateUrl: './add-mobile.component.html',
  styleUrls: ['./add-mobile.component.css']
})
export class AddMobileComponent implements OnInit {

  mob:Mobile = {mobileID:0,mobileName:'',mobilePrice:0,mobileBrand:''};
  constructor(private mobSer:MobileService, private router:Router) { }

  ngOnInit() {
  }

  addMobileForm= new FormGroup(  
    {
      mobileID: new FormControl(),
      mobileName: new FormControl(),
      mobilePrice: new FormControl(),
      mobileBrands: new FormControl()
    }
  );

  onSubmit(addMobileForm:FormGroup)
  {
    this.mob.mobileID = this.addMobileForm.controls['mobileID'].value;
    this.mob.mobileName = this.addMobileForm.controls['mobileName'].value;
    this.mob.mobilePrice = this.addMobileForm.controls['mobilePrice'].value;
    this.mob.mobileBrand = this.addMobileForm.controls['mobileBrands'].value;
    this.mobSer.addMob(this.mob);
    this.router.navigate(['/show']);

  }
}
