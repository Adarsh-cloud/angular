import { SearchEmployeeComponent } from './employee/search-employee.component';
import { EmployeeComponent } from './employee/employee.component';
import { HomeComponent } from './employee/home.component';
import { AddEmployeeComponent } from './employee/add-employee.component';
import { EmployeeListComponent } from './employee/employee-list.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  { path: "employees", component: EmployeeListComponent },
  { path: "add", component: AddEmployeeComponent },
  { path: "employees/:id", component: EmployeeComponent },
  { path: "search", component: SearchEmployeeComponent },
  { path: '', component: HomeComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
